﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Sprint0
{
    public interface ICommand
    {
        void Execute();
    }
}
